### Hexlet tests and linter status:
[![Actions Status](https://github.com/kuznetsovyar22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kuznetsovyar22/python-project-49/actions)
<a href="https://codeclimate.com/github/kuznetsovyar22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5a1d806bd3434f3ea70c/maintainability" /></a>
https://asciinema.org/a/Gd6zgfIoYK6sZ0kreD7FTLaD4
